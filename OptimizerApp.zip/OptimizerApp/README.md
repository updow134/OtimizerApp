# Optimizer

App de otimização Android que usa o Shizuku para rodar comandos com permissão de shell, sem root.

## Como abrir e rodar
1. Android Studio (Ladybug ou mais novo): File > Open > pasta `OptimizerApp`. Aguarde o Gradle sincronizar.
2. Instale e inicie o Shizuku no aparelho (Depuração sem fio ou ADB).
3. Rode o app, toque em "Permitir" no card de status e teste primeiro "Limpar cache" e "Monitor RAM/CPU".

## Estrutura
- `ui/ShizukuManager.kt`: estado do Shizuku, permissão e execução de comandos
- `ui/OptimizerViewModel.kt`: lista de ferramentas, validação de entrada e reversão automática
- `ui/OptimizerApp.kt`: telas e diálogos (Jetpack Compose)

## Observações
- Sem ícone de launcher próprio (usa o padrão do sistema).
- Limite de processos em segundo plano é experimental: o código do serviço varia por versão do Android.
- DPI e resolução revertem sozinhos em 10s se não confirmados.
