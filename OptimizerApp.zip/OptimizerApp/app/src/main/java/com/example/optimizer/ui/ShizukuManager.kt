package com.example.optimizer.ui

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState(val titulo: String, val detalhe: String) {
    CONECTADO("Shizuku ativo", "Permissão concedida. Todas as ferramentas liberadas."),
    SEM_PERMISSAO("Sem permissão", "Toque para autorizar o app no Shizuku."),
    INATIVO("Shizuku não está rodando", "Inicie o Shizuku via ADB ou Depuração sem fio.")
}

data class Resultado(val ok: Boolean, val saida: String)

object ShizukuManager {
    const val REQUEST_CODE = 1001

    fun estado(): ShizukuState = try {
        when {
            !Shizuku.pingBinder() -> ShizukuState.INATIVO
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.CONECTADO
            else -> ShizukuState.SEM_PERMISSAO
        }
    } catch (e: Throwable) {
        ShizukuState.INATIVO
    }

    fun pedirPermissao() {
        if (estado() == ShizukuState.SEM_PERMISSAO) Shizuku.requestPermission(REQUEST_CODE)
    }

    /** Roda um comando de shell com a permissão do Shizuku (shell/ADB). */
    suspend fun executar(comando: String): Resultado = withContext(Dispatchers.IO) {
        if (estado() != ShizukuState.CONECTADO) {
            return@withContext Resultado(false, "Shizuku não está conectado")
        }
        try {
            // stderr junto do stdout evita travar por buffer cheio
            val p = novoProcesso(arrayOf("sh", "-c", "($comando) 2>&1"))
            val saida = p.inputStream.bufferedReader().readText().trim()
            Resultado(p.waitFor() == 0, saida)
        } catch (e: Exception) {
            Resultado(false, e.message ?: "Erro desconhecido")
        }
    }

    // Shizuku.newProcess é privado desde a 13.x; reflexão funciona, mas o caminho
    // oficial é um UserService (AIDL). Dá pra migrar depois sem mudar o resto do app.
    private fun novoProcesso(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }
}
