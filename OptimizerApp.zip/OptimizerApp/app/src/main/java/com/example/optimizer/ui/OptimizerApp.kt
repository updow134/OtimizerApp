package com.example.optimizer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptimizerApp(vm: OptimizerViewModel = viewModel()) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        val estado by vm.estado.collectAsStateWithLifecycle()
        val ocupado by vm.ocupado.collectAsStateWithLifecycle()
        val saida by vm.saida.collectAsStateWithLifecycle()
        val reversao by vm.reversao.collectAsStateWithLifecycle()

        val snack = remember { SnackbarHostState() }
        var aba by remember { mutableIntStateOf(0) }
        var dialogo by remember { mutableStateOf<Ferramenta?>(null) }

        // Reavalia o Shizuku sempre que o app volta para a tela
        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.atualizar() }
        LaunchedEffect(Unit) { vm.mensagens.collect { snack.showSnackbar(it) } }

        val abas = listOf(
            "Início" to Icons.Default.Home,
            "Ferramentas" to Icons.Default.Build,
            "Ajustes" to Icons.Default.Settings,
        )

        Scaffold(
            topBar = { TopAppBar(title = { Text("Optimizer", fontWeight = FontWeight.Bold) }) },
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    abas.forEachIndexed { i, (nome, icone) ->
                        NavigationBarItem(
                            selected = aba == i,
                            onClick = { aba = i },
                            icon = { Icon(icone, contentDescription = nome) },
                            label = { Text(nome) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(Modifier.padding(padding)) {
                if (ocupado) LinearProgressIndicator(Modifier.fillMaxWidth())
                // Por enquanto todas as abas mostram a tela inicial
                HomeScreen(
                    estado = estado,
                    onPermitir = vm::pedirPermissao,
                    onAbrir = { f ->
                        if (f.campos.isEmpty() && f.aviso == null) vm.executar(f, emptyList())
                        else dialogo = f
                    },
                )
            }
        }

        dialogo?.let { f ->
            FerramentaDialog(
                f,
                onConfirmar = { valores -> dialogo = null; vm.executar(f, valores) },
                onFechar = { dialogo = null },
            )
        }
        saida?.let { SaidaDialog(it, vm::fecharSaida) }
        reversao?.let { ReversaoDialog(it, onManter = vm::manter, onReverter = vm::reverter) }
    }
}

@Composable
fun HomeScreen(
    estado: ShizukuState,
    onPermitir: () -> Unit,
    onAbrir: (Ferramenta) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ShizukuCard(estado, onPermitir)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            FERRAMENTAS.groupBy { it.categoria }.forEach { (categoria, lista) ->
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(categoria, style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
                items(lista) { f ->
                    FerramentaCard(f, habilitada = estado == ShizukuState.CONECTADO) { onAbrir(f) }
                }
            }
        }
    }
}

@Composable
fun ShizukuCard(estado: ShizukuState, onPermitir: () -> Unit) {
    val ok = estado == ShizukuState.CONECTADO
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (ok) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.errorContainer
        ),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (ok) Icons.Default.Check else Icons.Default.Warning, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(estado.titulo, fontWeight = FontWeight.Bold)
                Text(estado.detalhe, style = MaterialTheme.typography.bodySmall)
            }
            if (estado == ShizukuState.SEM_PERMISSAO) {
                Button(onClick = onPermitir) { Text("Permitir") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FerramentaCard(f: Ferramenta, habilitada: Boolean, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, enabled = habilitada, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(f.icone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(f.nome, fontWeight = FontWeight.SemiBold)
            Text(f.descricao, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun FerramentaDialog(f: Ferramenta, onConfirmar: (List<String>) -> Unit, onFechar: () -> Unit) {
    val valores = remember { mutableStateListOf<String>().apply { repeat(f.campos.size) { add("") } } }
    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text(f.nome) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                f.aviso?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error)
                }
                f.campos.forEachIndexed { i, rotulo ->
                    OutlinedTextField(
                        value = valores[i],
                        onValueChange = { valores[i] = it.trim() },
                        label = { Text(rotulo) },
                        singleLine = true,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirmar(valores.toList()) }, enabled = valores.all { it.isNotBlank() }) {
                Text("Aplicar")
            }
        },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } },
    )
}

@Composable
fun SaidaDialog(texto: String, onFechar: () -> Unit) {
    AlertDialog(
        onDismissRequest = onFechar,
        title = { Text("Monitor RAM/CPU") },
        text = {
            Text(
                texto.ifBlank { "Sem saída" },
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
            )
        },
        confirmButton = { TextButton(onClick = onFechar) { Text("Fechar") } },
    )
}

@Composable
fun ReversaoDialog(r: Reversao, onManter: () -> Unit, onReverter: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Manter alterações?") },
        text = { Text("Revertendo automaticamente em ${r.segundos}s.") },
        confirmButton = { TextButton(onClick = onManter) { Text("Manter") } },
        dismissButton = { TextButton(onClick = onReverter) { Text("Reverter") } },
    )
}
