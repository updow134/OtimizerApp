package com.example.optimizer.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

data class Ferramenta(
    val categoria: String,
    val nome: String,
    val descricao: String,
    val icone: ImageVector,
    val campos: List<String> = emptyList(),   // rótulos dos campos pedidos ao usuário
    val aviso: String? = null,
    val reverter: String? = null,             // comando de desfazer (contagem de 10s)
    val mostrarSaida: Boolean = false,
    val montar: (List<String>) -> String?,    // monta o comando; null = entrada inválida
)

private const val CODIGO_LIMITE_PROCESSOS = 51 // varia por versão do Android: validar

val FERRAMENTAS = listOf(
    Ferramenta("Rápidas", "Limpar cache", "Libera espaço dos apps", Icons.Default.Delete) {
        "pm trim-caches 999G"
    },
    Ferramenta("Rápidas", "Compilar ART", "Modo speed nos apps", Icons.Default.Build) {
        "cmd package compile -m speed -a"
    },
    Ferramenta("Rápidas", "Animações", "Escala 0.5x / 0x", Icons.Default.PlayArrow,
        campos = listOf("Escala (0, 0.5 ou 1)")) { v ->
        "settings put global window_animation_scale ${v[0]}; " +
            "settings put global transition_animation_scale ${v[0]}; " +
            "settings put global animator_duration_scale ${v[0]}"
    },
    Ferramenta("Rápidas", "Congelar apps", "Desativar bloatware", Icons.Default.Lock,
        campos = listOf("Pacote (ex: com.app.exemplo)")) { v ->
        "pm disable-user --user 0 ${v[0]}"
    },

    Ferramenta("Tela", "DPI", "Densidade da tela", Icons.Default.Edit,
        campos = listOf("DPI (ex: 420)"), reverter = "wm density reset",
        aviso = "Reverte sozinho em 10s se você não confirmar.") { v ->
        "wm density ${v[0]}"
    },
    Ferramenta("Tela", "Resolução", "Reduz para ganhar fluidez", Icons.Default.Search,
        campos = listOf("Resolução (ex: 1080x2400)"), reverter = "wm size reset",
        aviso = "Reverte sozinho em 10s se você não confirmar.") { v ->
        "wm size ${v[0]}"
    },
    Ferramenta("Tela", "Taxa de atualização", "60 / 90 / 120 Hz", Icons.Default.Refresh,
        campos = listOf("Hz (60, 90 ou 120)")) { v ->
        "settings put system min_refresh_rate ${v[0]}; settings put system peak_refresh_rate ${v[0]}"
    },

    Ferramenta("Apps", "Forçar parada", "Encerra um app agora", Icons.Default.Close,
        campos = listOf("Pacote")) { v ->
        "am force-stop ${v[0]}"
    },
    Ferramenta("Apps", "Permissões", "Conceder ou revogar", Icons.Default.Person,
        campos = listOf("Pacote", "Permissão (android.permission.X)", "grant ou revoke")) { v ->
        if (v[2] in setOf("grant", "revoke")) "pm ${v[2]} ${v[0]} ${v[1]}" else null
    },
    Ferramenta("Apps", "Remover bloatware", "Desinstala só para você", Icons.Default.Warning,
        campos = listOf("Pacote"),
        aviso = "Remove só para o usuário atual. Dá para restaurar com pm install-existing.") { v ->
        "pm uninstall -k --user 0 ${v[0]}"
    },

    Ferramenta("Sistema", "Limite em 2º plano", "Processos em segundo plano", Icons.Default.Settings,
        campos = listOf("Limite (-1 padrão, 0 a 4)"),
        aviso = "Experimental: o código do serviço muda conforme a versão do Android.") { v ->
        "service call activity $CODIGO_LIMITE_PROCESSOS i32 ${v[0]}"
    },
    Ferramenta("Sistema", "Monitor RAM/CPU", "Uso em tempo real", Icons.Default.Info,
        mostrarSaida = true) {
        "dumpsys meminfo | head -n 25; top -n 1 -b | head -n 12"
    },
)

data class Reversao(val comando: String, val segundos: Int)

class OptimizerViewModel : ViewModel() {
    private val _estado = MutableStateFlow(ShizukuManager.estado())
    val estado = _estado.asStateFlow()

    private val _ocupado = MutableStateFlow(false)
    val ocupado = _ocupado.asStateFlow()

    private val _saida = MutableStateFlow<String?>(null)
    val saida = _saida.asStateFlow()

    private val _reversao = MutableStateFlow<Reversao?>(null)
    val reversao = _reversao.asStateFlow()

    private val _mensagens = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val mensagens = _mensagens.asSharedFlow()

    private var jobReversao: Job? = null

    private val aoReceberBinder = Shizuku.OnBinderReceivedListener { atualizar() }
    private val aoPerderBinder = Shizuku.OnBinderDeadListener { atualizar() }
    private val aoResponderPermissao = Shizuku.OnRequestPermissionResultListener { _, _ -> atualizar() }

    init {
        Shizuku.addBinderReceivedListenerSticky(aoReceberBinder)
        Shizuku.addBinderDeadListener(aoPerderBinder)
        Shizuku.addRequestPermissionResultListener(aoResponderPermissao)
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(aoReceberBinder)
        Shizuku.removeBinderDeadListener(aoPerderBinder)
        Shizuku.removeRequestPermissionResultListener(aoResponderPermissao)
    }

    fun atualizar() { _estado.value = ShizukuManager.estado() }
    fun pedirPermissao() = ShizukuManager.pedirPermissao()
    fun fecharSaida() { _saida.value = null }

    fun executar(f: Ferramenta, valores: List<String>) {
        // Entradas vão para um shell: só aceita caracteres seguros (evita injeção).
        if (valores.any { !ENTRADA_SEGURA.matches(it) }) {
            avisar("Valor inválido: use só letras, números, . _ : -")
            return
        }
        val comando = f.montar(valores) ?: return avisar("Entrada inválida")

        viewModelScope.launch {
            _ocupado.value = true
            val r = ShizukuManager.executar(comando)
            _ocupado.value = false
            when {
                !r.ok -> avisar("Falhou: ${r.saida.take(120)}")
                f.mostrarSaida -> _saida.value = r.saida
                f.reverter != null -> iniciarReversao(f.reverter)
                else -> avisar("${f.nome}: concluído")
            }
        }
    }

    private fun iniciarReversao(comando: String) {
        jobReversao?.cancel()
        jobReversao = viewModelScope.launch {
            for (s in 10 downTo 1) {
                _reversao.value = Reversao(comando, s)
                delay(1000)
            }
            reverterAgora(comando)
        }
    }

    fun manter() {
        jobReversao?.cancel()
        _reversao.value = null
        avisar("Alteração mantida")
    }

    fun reverter() {
        val c = _reversao.value?.comando ?: return
        jobReversao?.cancel()
        reverterAgora(c)
    }

    private fun reverterAgora(comando: String) {
        viewModelScope.launch {
            ShizukuManager.executar(comando)
            _reversao.value = null
            avisar("Alteração revertida")
        }
    }

    private fun avisar(texto: String) { _mensagens.tryEmit(texto) }

    private companion object {
        val ENTRADA_SEGURA = Regex("^[A-Za-z0-9._:\\-]+$")
    }
}
